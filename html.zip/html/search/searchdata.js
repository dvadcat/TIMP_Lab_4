var indexSectionsWithContent =
{
  0: "acdekmn",
  1: "cm",
  2: "m",
  3: "cdem",
  4: "akn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные"
};

